INSERT INTO food_item (id, name, price) VALUES
(1, 'Veg Biryani', 120),
(2, 'Chicken Biryani', 180),
(3, 'Paneer Butter Masala', 150),
(4, 'Butter Naan', 40),
(5, 'Masala Dosa', 60),
(6, 'Gobi Manchurian', 100),
(7, 'Chicken 65', 130),
(8, 'Veg Fried Rice', 90),
(9, 'Egg Curry', 110),
(10, 'Lemon Soda', 30);
