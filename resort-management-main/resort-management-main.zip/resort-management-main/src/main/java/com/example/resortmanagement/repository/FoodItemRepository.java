// package com.example.resortmanagement.repository;

// import org.springframework.data.jpa.repository.JpaRepository;

// import com.example.resortmanagement.model.FoodItem;

// public interface FoodItemRepository extends JpaRepository<FoodItem, Integer> {
// }
