package com.example.resortmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResortManagementApplication {
    public static void main(String[] args) {
        SpringApplication.run(ResortManagementApplication.class, args);
    }
}
