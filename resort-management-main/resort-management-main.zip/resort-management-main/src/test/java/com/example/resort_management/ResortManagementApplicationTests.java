package com.example.resort_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResortManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
